import React from 'react'
import Card2 from './Card2'
import { Container } from '@mui/material'

function MainScreen() {
  return (
    <Container>
       <Card2/> 
    </Container>
  )
}

export default MainScreen