import React from 'react'
import Header from './Header'
import Footer from './Footer'
import MainScreen from './MainScreen'

function Scrren2() {
  return (
    <div>
        <Header/>
        <MainScreen/>
        <Footer/>
    </div>
  )
}

export default Scrren2